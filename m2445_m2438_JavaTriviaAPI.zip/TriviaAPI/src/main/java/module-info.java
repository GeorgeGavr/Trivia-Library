module TriviaAPI {
	exports gr.unipi.TriviaAPI;

	requires com.fasterxml.jackson.annotation;
	requires com.fasterxml.jackson.core;
	requires com.fasterxml.jackson.databind;
	requires java.desktop;
	requires org.apache.httpcomponents.httpclient;
	requires org.apache.httpcomponents.httpcore;
	requires org.json;
	requires junit;
	requires org.apache.commons.lang3;
	requires org.apache.commons.text;

	
}