package model;
import gr.unipi.TriviaAPI.*;



import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;
import org.junit.Assert;
import org.junit.Test;


public class TestAPI extends IOException {

	private static final String BASE_URL ="https://opentdb.com/api.php?amount=10";
	
	
	@Test
	public void testquest() throws IOException  {
		Procedures testproc = new Procedures();
		System.out.println("Return 5");
		testproc.setQuest();
		int noOfQuestions = testproc.getQuest();
		Assert.assertEquals(noOfQuestions,5);
		System.out.println("Test passed");
	}
	
	@Test
	public void testdiff() throws IOException   {
		String diff = "empty";
		boolean a=false;
		Procedures testproc = new Procedures();
		testproc.setDiff();
		if(testproc.getDiff()!=null) {
		diff = testproc.getDiff();
		}else {
			a=true;
		}

		switch(diff) {
		  case "easy" :
		    a=true;
		    break;
		  case "medium":
			  a=true;
		   break;
		  case  "hard":
			  a=true;
			  break;
		}

		Assert.assertTrue(a);
		System.out.println("Test passed");
	}
	

	
	@Test
	public void testBring() throws IOException  {

    //get request
    HttpClient client = HttpClients.createDefault();
    
    HttpGet request = new HttpGet(BASE_URL);

    //obtain response
    HttpResponse response = client.execute(request);
    String jsonResponse = EntityUtils.toString(response.getEntity());
    Assert.assertNotNull(jsonResponse);
    System.out.println("Test passed");
 
	}
	
	
	@Test
	public void testDefault() throws IOException, InterruptedException  {
	
			TimeUnit.SECONDS.sleep(5);
	//If you call it fast it will come back as fail
		String categ = null;
		String type = null;
		String diff = null;
		int noOfQuestions = 10;
		TriviaApiClient ApiTest =new TriviaApiClient();
		OpenTrivia trivia = ApiTest.fetchQuestions(noOfQuestions, type, categ, diff);
		Assert.assertEquals(trivia.getResponseCode(),0);
		System.out.println("Test passed");
	}

	
	
	
}
