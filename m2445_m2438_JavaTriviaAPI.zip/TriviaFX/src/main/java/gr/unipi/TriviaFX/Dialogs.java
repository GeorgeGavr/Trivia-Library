package gr.unipi.TriviaFX;


import javafx.scene.control.Alert;

import javafx.scene.control.Alert.AlertType;


public class Dialogs {

	public Dialogs() {
	}

	
	static void showAlert(String message, String title, AlertType type) {
        Alert alert = new Alert(type);
        alert.setTitle(title);
        alert.setContentText(message);
        alert.showAndWait();
    }
	
	

	
	
}
