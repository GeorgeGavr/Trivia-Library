package gr.unipi.TriviaFX;


import javafx.scene.Scene;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;

import gr.unipi.TriviaAPI.*;
import javafx.scene.control.Label;

import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.application.Platform;
import javafx.event.EventHandler;
import javafx.scene.layout.GridPane;

import java.util.List;

import org.apache.commons.text.StringEscapeUtils;

public class GameSceneCreate implements EventHandler<MouseEvent> {

	Label promptLabel;
	private GridPane mainPane; 

	private Button exit2Btn;
	private Button submitButton; 
	private Button buttonYes = new Button("Yes");
	private Button buttonNo = new Button("No");
	Button buttonBack = new Button("Back");
	Button buttonProc = new Button("Proceed");
	private int noOfQuestions; // Number of questions
	private String categ; // Category
	private String type; // Type(multiple or boolean)
	private String diff; // Difficulty of game
	private Button newButton;
	private Button newButton1;
	private Button newButton2;
	private Button newButton3;
	
	List<Result> TriviaList = new ArrayList<Result>();

	TextField inputField = new TextField();

	//Score and max Score + how many corrects for the end of program that informs of %
	private int Score = 0;
	private int maxScore;
	int correct = 0;
	private int sceneCounter = 0; // Counter for current scene number
	private int totalScenes = -1; // Number of transitions set by the user
	String correctAnswer;
	String[] quest2;

	public  GameSceneCreate() {
		mainPane = new GridPane();


	}

	public Scene createScene() {

		//Asking user Whether ton start the Game or Not
		Label promptLabel = new Label("Start the Game Adventure ?");
		submitButton = new Button("Begin"); // Initialize the submitButton here
		exit2Btn = new Button("Exit");
		
		
		GridPane gridPane = new GridPane();
		gridPane.setHgap(10);
		gridPane.setVgap(10);
		gridPane.add(promptLabel, 0, 0);
		gridPane.add(submitButton, 1, 1);
		gridPane.add(buttonBack, 2, 1);
		gridPane.add(exit2Btn, 3, 1);

		exit2Btn.setOnMouseClicked(this);
		submitButton.setOnMouseClicked(this);
		buttonBack.setOnMouseClicked(this);
		Scene scene1 = new Scene(gridPane, 400, 300);
		return scene1;

	}

	@Override
	public void handle(MouseEvent event) {

		//Exit Btn
		if (event.getSource() == exit2Btn) {
			App.primaryStage.close();
			Platform.exit();
			
			//Starting the game so we call API
		} else if (event.getSource() == submitButton) {
			callAPI();

			//To play again
		} else if (event.getSource() == buttonProc) {
			Score=0;
			playAgain();
			
			//Back to menu Btn
		} else if (event.getSource() == buttonBack || event.getSource() == buttonNo) {
			maxScore=0;
			App.primaryStage.setScene(App.mainScene);
			
		} else if (event.getSource() == buttonYes) {
			App.primaryStage.setScene(App.gameScene);
			
			//Handling the buttons of the questions that have inside them the answers
		} else if (event.getSource() == newButton) {

			if (newButton.getText().equals(this.correctAnswer)) {
				Score += 10; // Correct answer
				correct++; //To check how many correct ->%
				//Inform user of choice 
				Dialogs.showAlert("Correct Answer!", "Trivia API Game", AlertType.INFORMATION);
				//Continue the API 
				playAPI();

			} else {
				Score -= 5; // Incorrect answer
				//Inform user of choice and correct Answer
				
				Dialogs.showAlert("Wrong Answer! \nThe correct answer was: "+ this.correctAnswer, "Trivia API Game", AlertType.ERROR);
				playAPI();
			}
		} else if (event.getSource() == newButton1) {

			if (newButton1.getText().equals(this.correctAnswer)) {
				Score += 10; // Correct answer
				correct++;
				Dialogs.showAlert("Correct Answer!", "Trivia API Game", AlertType.INFORMATION);
				playAPI();

			} else {
				Score -= 5; // Incorrect answer
				Dialogs.showAlert("Wrong Answer! \nThe correct answer was: "+ this.correctAnswer, "Trivia API Game", AlertType.ERROR);
				playAPI();
			}
		} else if (event.getSource() == newButton2) {

			if (newButton2.getText().equals(this.correctAnswer)) {
				Score += 10; // Correct answer
				correct++;
				Dialogs.showAlert("Correct Answer!", "Trivia API Game", AlertType.INFORMATION);
				playAPI();

			} else {
				Score -= 5; // Incorrect answer
				Dialogs.showAlert("Wrong Answer! \nThe correct answer was: "+ this.correctAnswer, "Trivia API Game", AlertType.ERROR);
				playAPI();
			}
		} else if (event.getSource() == newButton3) {

			if (newButton3.getText().equals(this.correctAnswer)) {
				Score += 10; // Correct answer
				correct++;
				Dialogs.showAlert("Correct Answer!", "Trivia API Game", AlertType.INFORMATION);
				playAPI();

			} else {
				Score -= 5; // Incorrect answer
				Dialogs.showAlert("Wrong Answer! \nThe correct answer was: "+ this.correctAnswer, "Trivia API Game", AlertType.ERROR);
				playAPI();
			}
		}

	}

	public void showFinalScene() {

		//Show final result of game
		double percentage = (double) correct / (double) noOfQuestions * 100;
		
		//initializing for next game . Not used anymore
		sceneCounter=0;
		correct=0;
		
		if (Score<0) {
			Score=0;
		}
		Label finalLabel = new Label("Quiz Completed! Final Score: " + Score + "\nPercentage : " + percentage + " %");
		if (Score > maxScore) {
			maxScore = Score;
			finalLabel = new Label("Quiz Completed! Final Score: " + Score + "\nPercentage : " + percentage + " %"
					+ "\nNew High Score !!! ");

		}

		GridPane gridPane = new GridPane();
		gridPane.add(finalLabel, 0, 0);
		gridPane.add(buttonProc, 1, 1);
		
		buttonProc.setOnMouseClicked(this);
		
		Scene finalScene = new Scene(gridPane, 400, 300);

		App.primaryStage.setScene(finalScene);
	}

	public void playAPI() {

		if (sceneCounter >= totalScenes) {
			// End the query when quest are less than counter 
			showFinalScene();
			return;
		}
		//GET DATA of Trivia
		Result result = Procedures.getTriviaList().get(sceneCounter);

		
		//Shuffling stuff and bring them to FX
		ArrayList<String> possibleAnswers = new ArrayList<String>();
		possibleAnswers.add(result.getCorrectAnswer());
		possibleAnswers.addAll(result.getIncorrectAnswers());
		Collections.shuffle(possibleAnswers);

		String[] options = possibleAnswers.toArray(new String[0]);

		
		String quest = "Question no." +( sceneCounter+1) + "\nDifficulty: " + result.getDifficulty() + "\nType: "
				+ Procedures.getNameType(result.getType()) + "\n Category: " + result.getCategory() + "\n Question: "
				+ result.getQuestion();

		this.correctAnswer = result.getCorrectAnswer();
		//Monitor
		//System.out.println("No:" + sceneCounter + " answer " + correctAnswer);
		Label promptLabel = new Label(quest);
		GridPane gridPane = new GridPane();
		gridPane.setHgap(10);
		gridPane.setVgap(10);
		gridPane.add(promptLabel, 1, 0);
		
		//How many Buttons to make

		if (result.getType().equals("boolean")) {
			newButton = new Button(StringEscapeUtils.unescapeHtml4(options[0]));
			gridPane.add(newButton, 1, 2);
			newButton1 = new Button(StringEscapeUtils.unescapeHtml4(options[1]));
			gridPane.add(newButton1, 1, 3);
			newButton.setOnMouseClicked(this);
			newButton1.setOnMouseClicked(this);
		} else if (result.getType().equals("multiple")) {
			newButton = new Button(StringEscapeUtils.unescapeHtml4(options[0]));
			gridPane.add(newButton, 1, 2);
			newButton1 = new Button(StringEscapeUtils.unescapeHtml4(options[1]));
			gridPane.add(newButton1, 1, 3);
			newButton2 = new Button(StringEscapeUtils.unescapeHtml4(options[2]));
			gridPane.add(newButton2, 1, 4);
			newButton3 = new Button(StringEscapeUtils.unescapeHtml4(options[3]));
			gridPane.add(newButton3, 1, 5);
			newButton.setOnMouseClicked(this);
			newButton1.setOnMouseClicked(this);
			newButton2.setOnMouseClicked(this);
			newButton3.setOnMouseClicked(this);

		}
		sceneCounter++;
		Scene scene2 = new Scene(gridPane, 700, 400);

		App.primaryStage.setScene(scene2);

	}

	public void callAPI() {

		//Calling the API
		TriviaApiClient client = new TriviaApiClient();
		
		//Get the arguments for API
		noOfQuestions = Procedures.getQuest();
		categ = Procedures.getCateg();
		type = Procedures.getType();
		diff = Procedures.getDiff();
		List<Result> TriviaList = new ArrayList<Result>();
		totalScenes = noOfQuestions;

		//Fetch the json 
		try {
			OpenTrivia trivia = client.fetchQuestions(noOfQuestions, type, categ, diff);
	
			if (trivia.getResponseCode() == 0) {
				
				//Console Checking
				/*
				System.out.println("Test complete " + noOfQuestions);
				String resultList = trivia.toString();
				
				Checking encoded characters
				String resultListesc=StringEscapeUtils.unescapeHtml4(resultList);
				System.out.println(resultListesc);
				*/
				Procedures.setTriviaList(TriviaList);

				for (Result r : trivia.getResults()) {
					Result re = new Result(r.getType(), r.getDifficulty(), r.getCategory(), r.getQuestion(),
							r.getCorrectAnswer(), r.getIncorrectAnswers());
					TriviaList.add(re);
				}
				
				
				playAPI();

				//Broken API (?)
			}else if (trivia.getResponseCode() ==5) {
			Dialogs.showAlert("Take a brake User! . You are clicking way too fast ! ", "Trivia API Game", AlertType.ERROR);
				App.primaryStage.setScene(App.mainScene);
			}
			
			
			
			
			else {
				Dialogs.showAlert("Query does not exist. Please try other Parameters. ", "Trivia API Game", AlertType.ERROR);
				App.primaryStage.setScene(App.mainScene);
				return;
				
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
	
			e.printStackTrace();
		
		} catch (IndexOutOfBoundsException e) {
		    System.err.println("Error: Tried to access an element in an empty list.");
		    e.printStackTrace();
		    App.primaryStage.setScene(App.mainScene);
		    return;
		}
	
		

	}
 
	//Wanna play again ?
	public void playAgain() {

		Label playLabel = new Label("Do you want to play the same game again?");
		GridPane gridPane = new GridPane();
		gridPane.add(playLabel, 0, 0);
		gridPane.add(buttonYes, 1, 1);
		gridPane.add(buttonNo, 2, 1);
		gridPane.add(exit2Btn, 3, 1);

		buttonYes.setOnMouseClicked(this);
		buttonNo.setOnMouseClicked(this);
		exit2Btn.setOnMouseClicked(this);

		Scene playScene = new Scene(gridPane, 400, 200);

		App.primaryStage.setScene(playScene);

	}

}
