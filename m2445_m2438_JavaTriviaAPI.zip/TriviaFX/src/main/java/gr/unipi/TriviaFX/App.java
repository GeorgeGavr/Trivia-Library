package gr.unipi.TriviaFX;

import javafx.application.Application;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;
import gr.unipi.TriviaAPI.*;






public class App extends Application implements EventHandler<MouseEvent> {
	
	

	//Stage
	static Stage primaryStage;
	//Scenes
	static  Scene mainScene,gameScene;
	
    @Override
    public void start(Stage primaryStage) {
    	
    	//Greeting Msg
    	
    	Dialogs.showAlert("Hello User!\nWelcome to our Trivia Game" , "Trivia API Game", AlertType.INFORMATION);
    	App.primaryStage=primaryStage;
    	primaryStage.setTitle("Trivia API Game");
    	
    	//Main scene where settings are configured
    	MainSceneCreate mainSceneCr =new MainSceneCreate();
    	mainScene =mainSceneCr.createmainScene();

    	
    	//Scene where game is played
    	GameSceneCreate GameSceneCreate =new GameSceneCreate();
    	gameScene =GameSceneCreate.createScene();
    	
    	
//set main scene
    	primaryStage.setScene(mainScene);
    	primaryStage.show();
    	
      
    	
    	
    }

    public static void main(String[] args) {
        launch(args);

        

    }

	@Override
	public void handle(MouseEvent event) {

		
	}

}