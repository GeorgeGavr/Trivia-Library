package gr.unipi.TriviaFX;


import javafx.scene.Scene;
import gr.unipi.TriviaAPI.*;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;

import javafx.scene.control.Button;

import javafx.scene.text.Text;

import javafx.application.Platform;
import javafx.event.EventHandler;
import javafx.geometry.Pos;


import javafx.scene.layout.GridPane;

public class MainSceneCreate implements EventHandler<MouseEvent> {

	//Declaring variables
    private GridPane mainPane; 
    private GridPane settingsPane;
    
    //Buttons for configuration of game
    private Button defaultSettings;
    private Button customSettings;
    // Exit button
    private Button exitBtn;
    private Button exitMainBtn = new Button("Exit");
    
    // Buttons
    private Button submitButton; 
    private Button submitButton2;  
    private Button buttoneasy;
    private Button buttonmedium;
    private Button buttonhard;
    private Button buttonrandom;
    Button buttontf = new Button("True/False");
    Button buttonmult = new Button("Multiple");
    Button buttonrandmult = new Button("Random");

    //TextsF & Labels
    private Label promptLabel = new Label("Enter an integer between 1 and 50:");
    TextField inputField = new TextField();
    int a;

    public MainSceneCreate() {
    	
        // Create question for start of game
        Text question = new Text("Please choose your preferred settings to start the game.");

        // Create a GridPane for settings
        settingsPane = new GridPane();
        defaultSettings = new Button("Default Settings");
        customSettings = new Button("Custom Settings");
        
        settingsPane.add(defaultSettings, 0, 0);
        settingsPane.add(customSettings, 1, 0);
        settingsPane.add(exitMainBtn, 2, 0);
        settingsPane.setHgap(25);
        
     // Attach events
        defaultSettings.setOnMouseClicked(this);
        customSettings.setOnMouseClicked(this);
        exitMainBtn.setOnMouseClicked(this);

        // Create the main Pane
        mainPane = new GridPane();
        mainPane.add(question, 0, 0);
        mainPane.add(settingsPane, 0, 1);

        //Align Main Pane
        mainPane.setVgap(50);
        mainPane.setAlignment(Pos.CENTER);

        

    }

    Scene createmainScene() {
        
      
// Start the Scene with the method above
        return new Scene(mainPane, 600, 400);
    }

    void quests() {
        
    	//Declaring some stuff
        inputField = new TextField();
        submitButton = new Button("Submit"); 
        exitBtn = new Button("Exit");
        promptLabel= new Label("Enter an integer between 1 and 50:");

        GridPane gridPane = new GridPane();
        //Allign Pane 
        
        gridPane.setHgap(10);
        gridPane.setVgap(10);
        gridPane.add(promptLabel, 0, 0);
        gridPane.add(inputField, 1, 0);
        gridPane.add(submitButton, 1, 1);
        gridPane.add(exitBtn, 2, 1);
        
        // Attach events
        submitButton.setOnMouseClicked(this); 
        exitBtn.setOnMouseClicked(this); 

        //Start New Scene with above stuff and when User presses custom and goes from handle here
        Scene scene1 = new Scene(gridPane, 550, 350);
        App.primaryStage.setScene(scene1);

       
       
    }
    
    
    
    void type() {
    	//4q or TF or random
    	Text question = new Text("Please choose your type of questions. ");
    	settingsPane = new GridPane();
    	exitBtn = new Button("Exit");
        settingsPane.add(buttontf, 1, 0);
        settingsPane.add(buttonmult, 2, 0);
        settingsPane.add(exitBtn, 4, 0);
        settingsPane.add(buttonrandmult, 3, 0);
        
        
        mainPane = new GridPane();
        mainPane.add(question, 0, 0);
        mainPane.add(settingsPane, 0, 1);

        mainPane.setVgap(20);
        mainPane.setAlignment(Pos.CENTER);
 
        Scene scene2 = new Scene(mainPane, 450, 500);
        App.primaryStage.setScene(scene2);
        
        buttontf.setOnMouseClicked(this);
        buttonmult.setOnMouseClicked(this);
        buttonrandmult.setOnMouseClicked(this);
        exitBtn.setOnMouseClicked(this);
    }

    // Handling of buttons when we press them . This gives the flow of the program
    @Override
    public void handle(MouseEvent event) {

        if (event.getSource() == defaultSettings) {
        	//pressed button gives us the predecided
            Procedures.setDefault();
            App.primaryStage.setScene(App.gameScene);
        } else if (event.getSource() == customSettings) {
        	//Start here to enter arguments
            quests();
        } else if (event.getSource() == buttoneasy) {
            Procedures.setDiffbring(0);
            type();
        } else if (event.getSource() == buttonmedium) {
            Procedures.setDiffbring(1);
            type();
        } else if (event.getSource() == buttonhard) {
            Procedures.setDiffbring(2);
            type();
        } else if (event.getSource() == buttonrandom) {
            Procedures.setDiffbring(3);
            type();
        } else if (event.getSource() == exitBtn || event.getSource() == exitMainBtn) {
        	//Closing whole app
            App.primaryStage.close(); 
            Platform.exit();
        } else if (event.getSource() == buttonmult ) {
        	Procedures.setTypebring(0);
        	App.primaryStage.setScene(App.gameScene);
        	
        } else if (event.getSource() ==  buttontf ) {
        	Procedures.setTypebring(1);
        	App.primaryStage.setScene(App.gameScene);
        	
        } else if (event.getSource() ==  buttonrandmult ) {
        	Procedures.setTypebring(2);
        	App.primaryStage.setScene(App.gameScene);
        	
        } else if (event.getSource() == submitButton2) {
        	//Choosing Difficulty
        	String[] diff = { "Easy", "Medium", "Hard", "Random" };
        	
        	
        	Text question = new Text("Please choose your preferred difficulty. ");

            // Create a GridPane for difficulty setting +buttons + positionings
            settingsPane = new GridPane();
            buttoneasy = new Button(diff[0]);
            buttonmedium = new Button(diff[1]);
            buttonhard= new Button(diff[2]);
            buttonrandom= new Button(diff[3]);
            exitBtn = new Button("Exit");
            settingsPane.add(buttoneasy, 1, 0);
            settingsPane.add(buttonmedium, 2, 0);
            settingsPane.add(buttonhard, 3, 0);
            settingsPane.add(buttonrandom, 4, 0);
            settingsPane.add(exitBtn, 5, 0);
            
            //Setting horizontal width y row
            settingsPane.setHgap(10);

            // Create the main Pane
            mainPane = new GridPane();
            mainPane.add(question, 0, 0);
            mainPane.add(settingsPane, 0, 1);

          //Setting Vertical width x row
            mainPane.setVgap(20);
            mainPane.setAlignment(Pos.CENTER);
     
            Scene scene2 = new Scene(mainPane, 450, 500);
            App.primaryStage.setScene(scene2);
            
            // Attach events
            buttoneasy.setOnMouseClicked(this);
            buttonmedium.setOnMouseClicked(this);
            buttonhard.setOnMouseClicked(this);
            buttonrandom.setOnMouseClicked(this);
            exitBtn.setOnMouseClicked(this);

            
        } else if (event.getSource() == submitButton ) {
            try {
            	//Check if user does correct the input of No.
                int userInput = Integer.parseInt(inputField.getText());
                if (userInput < 1 || userInput > 50) {
                    throw new NumberFormatException("Out of range");
                }

                //Setting on Procedures the No. of Quests
                Procedures.setNoofquest(userInput);
                
            
                GridPane gridPane2 = new GridPane();
                gridPane2.setHgap(10); // Horizontal gap between columns
                gridPane2.setVgap(10); // Vertical gap between rows
              

                exitBtn = new Button("Exit");
                submitButton2 = new Button("Submit");
                
                //Bringing categories
                String[][] categories=Procedures.categbring();

            	// Create a Table With the categories to be included in the Question
    			String[] categoryNames = new String[categories.length];
    			for (int i = 0; i < categories.length; i++) {
    				categoryNames[i] = categories[i][1];
    			}

                
                // Create ListView and populate it with options
                ListView<String> listView = new ListView<>();
                listView.getItems().addAll(categoryNames);

                // Handle selection of the ListView to give us the selected Categ
                listView.getSelectionModel().selectedItemProperty().addListener((observable, oldValue, newValue) -> {
                	
                	//Console Checking
                   // System.out.println("You selected: " + newValue);
                	
                	
                	
                	//seeing with is equal according to name and the return to Procedures the Id
                    if (newValue != null) {

        				for (String[] category : categories) {
        					if (category[1].equals(newValue)) {
        						Procedures.setSelectedId(category[0]);
        						//Console Checking
        						//System.out.println(newValue+" Test "+category[0]);

        						break;
        					}
        				}
                    }
                });

                

    				
                // Add the ListView to the GridPane
                gridPane2.add(listView, 0, 0);  
                gridPane2.add(submitButton2, 2, 0); 
                gridPane2.add(exitBtn, 3, 0); 
                
                //Stage & scene for next ask of questions
                Scene scene2 = new Scene(gridPane2, 450, 500);
                
                App.primaryStage.setScene(scene2);
                submitButton2.setOnMouseClicked(this); 
                exitBtn.setOnMouseClicked(this); 

            } catch (NumberFormatException ex) {
            	
            	//Exception so user is informed on  what to enter 
                promptLabel.setText("Invalid input. Please enter a number between 1 and 50.");
                
            }
        }
    }
}