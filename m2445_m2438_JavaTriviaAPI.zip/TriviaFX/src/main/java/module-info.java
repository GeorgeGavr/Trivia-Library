module gr.unipi.TriviaFX {
    requires javafx.controls;
    exports gr.unipi.TriviaFX;
    requires TriviaAPI;
	requires java.desktop;
	requires javafx.graphics;
	requires java.xml;
	requires javafx.base;
	requires org.apache.commons.text;
}
